import xbmcaddon

MainBase = 'https://goo.gl/0FyFEO'
MainBase = 'https://goo.gl/ZL2f8L'
addon = xbmcaddon.Addon('plugin.video.KahlonTv')